#' @name convKernel
#' @title Generate normalised 1-D convolution kernels (point-spread functions)
#'
#' @description
#' Generates a numeric vector of length \emph{L} that represents a
#' point-spread function (PSF) or impulse-response kernel.
#' The kernel is \eqn{L^{1}}-normalised (area = 1).
#' Optionally it is shifted with \code{\link{shiftKernel}} so that a
#' user-chosen percentile \eqn{perc} of the cumulative distribution falls on
#' index \eqn{1 + perc \cdot (L - 1)}; setting \code{perc = 0} leaves the
#' kernel unshifted.  Alternatively, using \code{perc = "mean"} will move the
#' centroid to the middle of the kernel.
#'
#' The helper is useful for simulating blurred spike trains as observed in
#' one-dimensional spectroscopy (GC-MS, NMR), calcium neuro-imaging, or
#' epidemic curves where diagnosed cases are obtained by convolving
#' infections with a delay-distribution kernel.  Some of the available
#' kernel families are:
#'
#' \itemize{
#'   \item \strong{Gaussian / Bigaussian / Exponentially Modified
#'         Gaussian (Gaussian * Exp)} - common
#'         peak-shape models in gas-chromatography / mass-spectrometry.
#'   \item \strong{Lorentzian} - arises in 1-D NMR as the Fourier transform
#'         of an exponentially decaying free-induction decay
#'         (Cauchy-Lorentz distribution).
#'   \item \strong{Exponential} - standard calcium-indicator impulse
#'         response in neuro-imaging studies.
#'   \item \strong{Gamma / Gamma * Exp} - typical
#'         infection-to-diagnosis delay distributions in epidemiology and
#'         also sometimes used for chromatographic peak shapes.
#' }
#'
#' All kernels returned by \code{convKernel()} integrate to 1 and are ready
#' for use in convolution or deconvolution pipelines.
#'
#' @param type  One of `"gaussian"`, `"bigaussian"`, `"emg"` (exponentially
#'   modified Gaussian), `"lorentzian"` (Cauchy), `"laplace"` (two-sided
#'   exponential), `"exponential"` (one-sided exponential), `"gamma"`,
#'   `"gammaexp"` (convolution of Gamma with exponential).
#' @param L     Integer (>= 3).  Kernel length.
#' @param params Named list of shape parameters (see Details).
#' @param perc Numeric in [0, 1] or "mean".
#'   Position the chosen percentile of the kernel's CDF at index
#'   `1 + perc*(L - 1)` or `mean` for centroid centering.
#'   Defaults to `0` for causal families
#'   (`exponential`, `gamma`, `gammaexp`) and to `mean`
#'   for all other types (resulting in centroid centering).
#'
#' @details Default parameters for the different distributions are as
#'   follows:\cr gaussian: `sigma=2.5`\cr bigaussian:  `sigma1=1`, `sigma2=5`\cr
#'   emg (gaussian * exponential):`sigma=2`,`tau=6 ` lorentzian: `gamma=2`\cr
#'   laplace: `tau=3`\cr exponential: `tau=3`\cr gamma: `k=9`, `tau=0.5`\cr
#'   gammaexp (gamma * exponential): `k=9` , ` tau_g=0.7` , `tau_e=0.7` \cr
#'
#' Returned vectors are **L^1-normalised**.
#' If `align_percentile > 0` the kernel is shifted (by sub-sample
#' interpolation) so that the requested percentile lies at its
#' theoretical position inside the length-*L* vector.
#'
#' @return Numeric vector of length *L*.
#'
#' @example examples/convKernel.R
#' @importFrom gsignal conv
#' @importFrom stats   approx
#' @seealso
#'   \code{\link{shiftKernel}}, \code{\link{convMatrix}}
#' @export
#' @author
#' Tom Wenseleers \email{tom.wenseleers@kuleuven.be} \\
#' Laboratory of Socioecology and Social Evolution, KU Leuven \\
#' \url{https://bio.kuleuven.be/eeb/tw/research} \\
#' ORCID: \href{https://orcid.org/0000-0002-1434-861X}{0000-0002-1434-861X}
convKernel <- function(type = c("gaussian","bigaussian","emg","lorentzian",
                                "laplace","exponential","gamma","gammaexp"),
                   L,
                   params  = list(),
                   perc = NULL)
{
  `%||%` <- function(a,b) if (is.null(a)) b else a
  type <- match.arg(type)
  stopifnot(L >= 3L, L == as.integer(L))

  ## ---------------- choose default alignment ----------------------------
  if (is.null(perc)) {
    causal  <- type %in% c("exponential","gamma","gammaexp")
    perc <- if (causal) 0 else "mean"
  }
  stopifnot((is.numeric(perc) && 0 <= perc && perc <= 1) || is.character(perc))

  idx <- seq_len(L)
  x   <- idx - (L + 1)/2        # symmetric grid for analytic formulas

  ## ---- analytic kernels -------------------------------------------------
  kernel <- switch(type,

              gaussian = {
                s <- params$sigma %||% 2.5
                1/(sqrt(2*pi)*s) * exp(-x^2/(2*s^2))
              },

              bigaussian = {
                s1 <- params$sigma1 %||% 1
                s2 <- params$sigma2 %||% 5
                delta <- (s2 - s1) * sqrt(2/pi)
                x0 <- x + delta
                out <- ifelse(x0 <= 0,
                              exp(-x0^2/(2*s1^2)),
                              exp(-x0^2/(2*s2^2)))
                out / (sqrt(pi/2)*(s1 + s2))
              },

              emg = {
                s   <- params$sigma %||% 2
                tau <- params$tau   %||% 6
                lambda_rate <- 1/tau
                pref <- lambda_rate/2 * exp(lambda_rate*(lambda_rate*s^2/2 - x))
                pref * 2*pnorm(-(lambda_rate*s^2 - x)/(s*sqrt(2)))
              },

              lorentzian = {
                gamma_par <- params$gamma %||% 2
                gamma_par / pi / (x^2 + gamma_par^2)
              },

              laplace = {
                tau <- params$tau %||% 3
                1/(2*tau) * exp(-abs(x)/tau)
              },

              exponential = {
                tau <- params$tau %||% 3
                out <- numeric(L)
                t   <- idx - 1                       # t = 0,1,2,...
                out <- 1/tau * exp(-t/tau)
                out
              },

              gamma = {
                k   <- params$k   %||% 9
                tau <- params$tau %||% 0.5
                t   <- idx - 1
                rate <- 1/tau
                out <- rate^k / gamma(k) * t^(k-1) * exp(-rate*t)
                out
              },

              gammaexp = {
                k      <- params$k      %||% 9
                tau_g  <- params$tau_g  %||% 0.7   # Gamma scale
                tau_e  <- params$tau_e  %||% 0.7   # Exp   scale

                t  <- idx - 1                     # 0,1,2,...
                if (tau_g==tau_e) {
                  # discrete Gamma density with shape k=k+1 & rate = 1/tau_g = 1/tau_e
                  k <- k+1
                  g <- (t^(k-1) * exp(-t/tau_g)) /
                    (gamma(k) * tau_g^k)

                } else {
                # discrete Gamma density (shape k, rate = 1/tau_g)
                g1 <- (t^(k-1) * exp(-t/tau_g)) /
                  (gamma(k) * tau_g^k)
                # discrete Exponential density (rate = 1/tau_e)
                g2 <- 1/tau_e * exp(-t/tau_e)

                # linear convolution
                g  <- gsignal::conv(g1, g2, shape = "full")[1:L]
                }
                g
              }
  )

  ## ---- shift kernel ------------------------------------------------------
  kernel <- shiftKernel(kernel, perc, method = "linear")

  ## ---- return kernel normalised to unit L1 norm --------------------------
  return(kernel / sum(kernel))
}




#' @rdname convKernel
#'
#' @param kernel Numeric vector - the PSF to be shifted.
#' @param perc   Either `"mean"` (shift the centroid) or a
#'               numeric percentile in [0, 1].
#' @param method `"linear"` (sub-sample interpolation) or
#'               `"integer"` (whole-sample shift).
#' @return shifted vector of the same length as `kernel`
#' @export
shiftKernel <- function(kernel,
                         perc = "mean",
                         method = c("linear", "integer"))
{
  method <- match.arg(method)
  if (!is.vector(kernel)) kernel <- as.vector(kernel)
  stopifnot(is.numeric(kernel),
            length(kernel) >= 3L,
            (is.numeric(perc) && 0 <= perc && perc <= 1) || is.character(perc))

  L   <- length(kernel)
  idx <- seq_len(L)

  ## -------- locate the reference point ---------------------------------
  if (is.character(perc)) {

    ## centroid (= mean)
    pos <- sum(idx * kernel) / sum(kernel)

  } else if (perc == 0) {

    ## 0-percentile  -> left boundary
    pos <- 1

  } else if (perc == 1) {

    ## 100-percentile -> right boundary
    pos <- L

  } else {

    ## p-quantile inside (0, 1)  ------------------------------------------
    cdf <- cumsum(kernel) / sum(kernel)
    pos <- stats::approx(cdf, idx, xout = perc,
                         ties = "ordered", rule = 2)$y
  }

  ## -------- where we want it -------------------------------------------
  target <- if (is.character(perc)) { (L + 1) / 2 } else {  # centre for centroid
    1 + perc * (L - 1)                                      # 1-based percentile
  }

  delta  <- target - pos                           # +ve -> shift right
  if (abs(delta) < .Machine$double.eps)
    return(kernel / sum(kernel))                             # already aligned

  out <- switch(method, linear = {
    f <- stats::approxfun(idx, kernel, yleft = 0, yright = 0)
    f(idx - delta)
  }, integer = {
    s <- round(delta)                            # integer shift
    if (s > 0)
      c(rep(0, s), head(kernel, L - s))
    else if (s < 0)
      c(tail(kernel, L + s), rep(0, -s))
    else
      kernel
  })

  out / sum(out)                                   # keep L^1 = 1
}
