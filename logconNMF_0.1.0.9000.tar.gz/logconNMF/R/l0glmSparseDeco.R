#' @name l0glmSparseDeco
#' @title Sparse deconvolution with a fixed PSF via L0-penalised GLMs
#'
#' @description
#' Estimates the \emph{latent}, un-blurred single or multichannel spike train 
#' \eqn{a} from an observed signal \eqn{y} that is assumed to follow the 
#' convolution model
#' \deqn{y \;=\; X(g)\,a + \varepsilon,}
#' where \eqn{X(g)} is a Toeplitz design matrix that contains
#' time-shifted copies of a known point-spread function \eqn{g} (PSF, a.k.a. convolution 
#' kernel) and errors \eqn{\varepsilon} are assumed to be drawn from an exponential 
#' family error distribution (e.g. Poisson, Gaussian, Gamma, Inverse Gaussian). 
#' The coefficient vector (or matrix) \eqn{a} is found with \emph{best-subset} 
#' or \emph{best-subset of group selection} via \pkg{L0glm}.
#' 
#' @details
#' The algorithm is inspired by the L0-penalised deconvolution approach
#' of de Rooi & Eilers (2011) for chromatographic pulse trains, but it
#' leverages the general machinery of \pkg{L0glm}.  This results in the following
#' improvements:
#' \itemize{
#'   \item No manual tuning of the regularisation parameter is required; instead
#'         it can be preset to approximate information criteria such as GIC, AIC,
#'         BIC, EBIC or MBIC
#'   \item Both single channel data with L0 best subset selection or 
#'         multichannel data with grouped L0 best subset of group selection 
#'         are allowed for         
#'   \item Any exponential-family noise model with an \emph{identity} link
#'         can be used (Poisson, Gaussian, Gamma, ...)
#'   \item The underlying sparse design is handled by Eigen's efficient sparse
#'         Cholesky solver, enabling large problems to be tackled quickly
#' }
#' 
#' In the non-negative-matrix-factorisation (NMF) literature this model
#' would be referred to as \emph{single-atom convolutional NMF} or \emph{sparse 
#' convolutional dictionary learning}, whereby a one-dimensional signal (or
#' multichannel matrix) \eqn{y} is approximated as \eqn{W(g)\,H}, where \eqn{W(g)}
#' is a banded Toeplitz matrix that holds time-shifted copies of
#' a fixed dictionary atom/PSF \eqn{g}, and \eqn{H} is a
#' (potentially multi-column) matrix of sparse, non-negative activations
#' \eqn{a}.
#' However, relative to standard single-atom convolutional NMF we 
#' offer several extensions:
#' \itemize{
#'   \item \emph{Optimal sparsity}: we do not fix the sparsity level of the 
#'       activations \eqn{a} in advance; instead we let \pkg{L0glm} perform
#'       best-subset or best subset of group selection through an
#'       L\eqn{_{0}} or grouped L\eqn{_{0}} penalty,
#'   \item \emph{General noise models}: any exponential-family likelihood
#'         with an \emph{identity} link is supported (Poisson, Gaussian,
#'         Gamma, inverse-Gaussian, ...), instead of only Gaussian
#'         (Euclidean-distance NMF) or Poisson (NMF with KL divergence)
#'   \item \emph{Speed}: the Toeplitz design is solved by sparse-Cholesky 
#'         linear algebra rather than multiplicative updates, giving 
#'         orders-of-magnitude speed-ups on long signals
#' }
#' Methodologically this could be referred to as
#' \emph{generalised / deviance matrix factorisation}
#' (Kidzinski et al. 2022; Castiglione et al. 2024; Wang & Carvalho 2023), 
#' specialised to the case where \eqn{W} is a Toeplitz single-atom convolutional 
#' dictionary matrix and where the matrix factorisation is solved with an 
#' L\eqn{_{0}} or grouped L\eqn{_{0}}-penalised generalised linear model (GLM)
#' fit via adaptive ridge regularised iteratively reweighted least squares 
#' (IRLS).
#' When a fitted baseline or known offset is present, positive backprojection
#' starts are calculated from the signal above a low channel-wise baseline.
#' This keeps promising peaks eligible during the initial adaptive-ridge steps.
#' These values initialize the coefficients only; the model always fits the
#' original observations with its fitted background and known offset.
#'
#' A classical baseline for Poisson deconvolution is the
#' Richardson-Lucy algorithm (Richardson 1972; Lucy 1974). In modern
#' terms, Richardson-Lucy equals Kullback-Leibler NMF with
#' multiplicative updates (Lee & Seung 1999) and  
#' factor matrix \eqn{W} constrained to be a convolution matrix.  
#' Empirically, \code{l0glmSparseDeco()} has much better support recovery,
#' attains much lower reconstruction error and is dramatically faster thanks to 
#' (i) closed-form sparse linear solves, (ii) the automatic selection of the penalty
#' parameter through information-criterion presets, and (iii) the possibility
#' to exploit grouped-sparsity when several channels are deconvolved jointly.
#'
#' @param y       Numeric vector or matrix; the observed (blurred) signal.
#'                A matrix is treated as \eqn{n \times m} outcome channels.
#' @param family  A GLM \link[stats]{family} object with an \emph{identity}
#'                link specifying the desired error distribution 
#'                (e.g. `poisson(identity)`, `gaussian(identity)`
#'                or `Gamma(identity)`).
#' @param kernel  Either a numeric vector that is the fixed PSF in forward time 
#'                order, or `NULL` together with `L` and `kernelfunc`, in which 
#'                case the PSF is generated on the fly (useful for simulations).
#' @param kernelfunc A function that returns a length-\eqn{L} numeric vector
#'                   when called as `kernelfunc(1:L)`. Defaults to a Gaussian with 
#'                   sigma=6.
#' @param L       Desired kernel length when `kernel` is `NULL`.
#' @param X       Optional.  A sparse design matrix that overrides
#'                the automatic call to \code{\link{convMatrix}}.  This is
#'                useful when you need time-varying PSFs.
#' @param baseline  Character.  One of
#'                  \code{NULL} (no baseline, default),
#'                  \code{"intercept"} (a single constant column),
#'                  or \code{"bspline"} (cubic B-spline basis).
#'                  The baseline columns are prepended to the Toeplitz
#'                  design and are \emph{always included} in the model.
#'                  Their fitted contribution is used as an \code{offset}
#'                  in the \code{l0glmDecoEstKernel} kernel-update step.
#' @param nknots    Integer >= 4.  Number of spline knots
#'                  to use when \code{baseline = "bspline"}. With \code{nknots < 4}
#'                  and \code{baseline="bspline"} \code{baseline} is changed
#'                  to \code{intercept}. 
#' @param IC Information criterion for the penalty preset; see \link{information_criteria}.
#' @param ... Execution controls passed to the spike/background
#'   \code{l0glmFit()} calls, such as \code{parallelize}, \code{ncores},
#'   \code{nthreads} and \code{openmp}. For small non-Poisson multichannel
#'   fits, \code{parallelize = FALSE} avoids worker-startup overhead.
#' @param grouped Logical, passed unchanged to \code{l0glmFit}, specifying
#'                whether to perform grouped L0 feature selection, i.e. best subset
#'                of group selection (BSGS), in case there are multiple outcome
#'                channels. Defaults to TRUE.
#' @param control.solver Optional solver-control list passed to \code{l0glmFit}.
#'                By default this uses Eigen sparse Cholesky LLT with AMD
#'                ordering. For strictly banded PSF designs, users can pass
#'                \code{controlSolverGen("eigen", method=1L, NaturalOrdering=TRUE)}
#'                to request Eigen natural ordering.
#' @param offset Optional known additive signal: a scalar, length-\eqn{n}
#'                vector, or \eqn{n\times m} matrix. Original observations are
#'                fitted with this model offset; counts are not background-subtracted.
#'
#' @return A list with
#' \describe{
#'   \item{\code{coef_spikes}}{Estimated un-blurred spikes, i.e. the coefficients
#'                             for design matrix \code{X_spikes}. Its dimensions
#'                             are \code{ncol(X_spikes)} by \code{ncol(as.matrix(y))}.}
#'   \item{\code{coef_baseline}}{Estimated baseline coefficients for baseline
#'                               design matrix \code{X_baseline}.}
#'   \item{\code{fitted_values}}{\eqn{X a}, the fitted signal.}
#'   \item{\code{fitted_baseline}}{\eqn{X a}, the fitted baseline}
#'   \item{\code{deviance}}{Residual deviance of the fit.}
#'   \item{\code{X_spikes}}{Toeplitz design matrix for the spikes.}
#'   \item{\code{X_baseline}}{Design matrix for the baseline.}
#'   \item{\code{offset}}{Known additive signal, expanded to the response dimensions.}
#'   \item{\code{fit}}{The underlying \code{L0glm_fit} model, supporting
#'     \code{logLik()}, \code{GIC()} and the other fitted-model methods.}
#' }
#'
#' @references
#'   \itemize{
#'     \item Richardson, W. H. (1972)\cr
#'           Bayesian-based iterative method of image restoration.\cr
#'           \emph{J. Opt. Soc. Am.} 62 (1): 55-59.
#'     \item Lucy, L. B. (1974)\cr
#'           An iterative technique for the rectification of observed
#'           distributions.\cr
#'           \emph{Astron. J.} 79: 745-754.
#'     \item Smaragdis, P. (2004)\cr
#'           Non-negative matrix factor
#'           deconvolution; extraction of multiple sound sources from
#'           monophonic inputs.\cr
#'           \emph{Proceedings of ICA 2004}.
#'     \item Lee, D. D., & Seung, H. S. (1999)\cr
#'           Learning the parts of objects by non-negative matrix
#'           factorization.\cr
#'           \emph{Nature} 401 (6755): 788-791.
#'     \item de Rooi, J., & Eilers, P. H. C. (2011)\cr
#'           Deconvolution of pulse trains with the L0 penalty.\cr
#'           \emph{Analytica Chimica Acta} 705 (1-2): 218-226.
#'     \item Kidzinski, L., Hui, F. K. C., Warton, D. I. and Hastie, T. (2022)\cr
#'           Generalized Matrix Factorization: efficient algorithms for fitting
#'           generalized linear latent variable models to large data arrays.\cr
#'           \emph{Journal of Machine Learning Research} 23(291): 1--29.
#'           \url{https://www.jmlr.org/papers/v23/20-1104.html}.
#'     \item Castiglione, C., Segers, A., Clement, L. and Risso, D. (2026)\cr
#'           Stochastic gradient descent estimation of generalized matrix factorization
#'           models with application to single-cell RNA sequencing data.\cr
#'           \emph{Biostatistics} 27(1), kxag010. \doi{10.1093/biostatistics/kxag010}.
#'     \item Wang, L. and Carvalho, L. E. (2023)\cr
#'           Deviance matrix factorization.\cr
#'           \emph{Electronic Journal of Statistics} 17(2): 3762--3810.
#'           \doi{10.1214/23-EJS2174}.
#'   }
#' 
#' @seealso
#'   \code{\link{l0glmDecoEstKernel}} for the complementary
#'   "estimate-the-kernel" step,  
#'   \code{\link{l0glmBlindDeco}} for the full alternating blind
#'   deconvolution,  
#'   \code{\link{convMatrix}} (design matrix) and
#'   \code{\link{convKernel}} (PSF generator).
#'
#' @example examples/l0glmSparseDeco.R
#' @importFrom Matrix Matrix Diagonal
#' @importFrom splines bs
#' @export
l0glmSparseDeco <- function(y,                         # response to be deconvolved (vector or matrix, i.e. univariate or multivariate)
                           family = poisson(identity),   # noise model, e.g. poisson/gaussian/Gamma, we only support identity link families here
                           kernel = NULL, # kernel: either vector with blur kernel or length of blur kernel L & kernelfunc
                           kernelfunc  = function(x)
                             convKernel("gaussian",
                                        L        = length(x),   # <- same length
                                        params   = list(sigma = 6),
                                        perc     = 0),          # no recentering as this PSF is already centered
                           L = if (!is.null(kernel)) length(kernel) else 51,
                           X = NULL, # (sparse) deconvolution kernel - can be used to specify matrix with time-varying PSFs & which would then override kernel
                           baseline    = NULL,
                           nknots      = max(4L, floor(nrow(as.matrix(y))/500)),
                           IC = "gic", # preset L0glm regularisation to approximately optimise this IC, choices aic, bic, gic, ebic or mbic
                           grouped = TRUE,  # use grouped feature selection (best subset of group selection), only used if outcome y is multivariate
                           control.solver = do.call("controlSolverGen",
                                                    list(solver = "eigen", method = 1L)),
                           offset = NULL, ...) {
  response <- L0glm_deco_response(y, family)
  y <- response$y; family <- response$family
  n <- nrow(y); m <- ncol(y)
  offset <- nmf_matrix(offset, n, m, 0, "offset")
  
  ## ---------- PSF design ----------
  if (is.null(X)) {
    if (is.null(kernel)) {
      L0glm_deco_length(L, "L", 3L)
      kernel <- kernelfunc(seq_len(L))
    }
    kernel <- L0glm_deco_kernel(kernel)
    X <- convMatrix(kernel = kernel, n = n)
  } else {
    if (!is.matrix(X) && !inherits(X, "Matrix")) X <- as.matrix(X)
    values <- if (inherits(X, "sparseMatrix")) X@x else X
    if (nrow(X) != n || ncol(X) < 1L || !is.numeric(values) ||
        any(!is.finite(values)) || any(values < 0))
      stop("X must be a finite nonnegative design with nrow(X) equal to nrow(y).", call. = FALSE)
  }

  ## ---------- baseline design ----------
  if (!is.null(baseline)) baseline <- match.arg(baseline, c("intercept", "bspline"))
  if (identical(baseline, "bspline")) {
    L0glm_deco_length(nknots, "nknots", 1L)
    if (nknots < 4L) baseline <- "intercept"
  }
  if (!is.null(baseline)) {
    if (baseline == "intercept") {
      X_base <- Matrix::Matrix(1, n, 1, sparse = TRUE)
    } else if (baseline == "bspline") {
      X_base <- splines::bs(seq_len(n), df = nknots, degree = 3, intercept = TRUE)
      X_base <- Matrix::Matrix(X_base, sparse = TRUE)
  }} else {
    X_base <- NULL
  }
  
  ## ---------- final model matrix ----------
  X_full <- if (is.null(X_base)) X else cbind(X_base, X)
  ## ---------- L0glm fit -------------------
  args <- utils::modifyList(list(y = y, X = X_full, family = family,
    intercept = FALSE, start = NULL, offset = offset, nonnegative = TRUE,
    lambda = IC, grouped = grouped,
    always.include = if (!is.null(X_base)) seq_len(ncol(X_base)) else NULL,
    normalize = "none", maxit = 100L, method = 1L, solver = "eigen",
    control.solver = control.solver, thresh = 1e-10, tol = 1e-4), list(...),
    keep.null = TRUE)
  fit <- do.call(l0glmFit, args)
  # Compulsory baseline terms are unpenalized and use the fitter's constrained
  # nuisance-block updates. Starting values have explicit coefficient dimensions.
  
  beta      <- fit$coefficients
  
  k_base    <- if (is.null(X_base)) 0 else ncol(X_base)
  beta_base <- if (k_base) beta[seq_len(k_base), , drop = FALSE] else NULL
  beta_spk  <- if (k_base!=0) beta[-seq_len(k_base), , drop = FALSE] else beta
  
  y_hat  <- X_full %*% beta + offset
  y_base <- if (!is.null(X_base)) X_base %*% beta_base else Matrix(0, ncol = ncol(y_hat), nrow = nrow(y_hat), sparse = TRUE)
  dev <- L0glm_deco_deviance(y, y_hat, family)
  
  return(list(coef_spikes     = beta_spk,
              coef_baseline   = beta_base,
              fitted_values   = y_hat,
              fitted_baseline = y_base,
              deviance        = dev,
              X_spikes        = X,
              X_baseline      = X_base,
              offset          = offset,
              fit             = fit))
}

# Shared input and scoring contracts for the three deconvolution steps.
L0glm_deco_response <- function(y, family) {
  if (is.function(family)) family <- family()
  if (!inherits(family, "family") || !identical(family$link, "identity"))
    stop("Deconvolution requires a GLM family with an identity link.", call. = FALSE)
  y <- as.matrix(y)
  if (!is.numeric(y) || !nrow(y) || !ncol(y) || any(!is.finite(y)))
    stop("y must be a finite numeric vector or matrix with nonzero dimensions.", call. = FALSE)
  storage.mode(y) <- "double"
  list(y = y, family = family)
}

L0glm_deco_length <- function(value, name, minimum) {
  if (!is.numeric(value) || length(value) != 1L || !is.finite(value) ||
      value < minimum || value != floor(value))
    stop(name, " must be an integer >= ", minimum, ".", call. = FALSE)
}

L0glm_deco_kernel <- function(kernel, normalize = FALSE) {
  kernel <- as.numeric(kernel)
  if (length(kernel) < 3L || any(!is.finite(kernel)) || any(kernel < 0) || sum(kernel) <= 0)
    stop("The kernel must contain at least three finite nonnegative values with positive sum.", call. = FALSE)
  if (normalize) kernel / sum(kernel) else kernel
}

L0glm_deco_deviance <- function(y, mu, family) {
  mu <- as.numeric(mu)
  if (!is.null(family$validmu) && !isTRUE(family$validmu(0)))
    mu <- pmax(mu, .Machine$double.eps)
  sum(family$dev.resids(as.numeric(y), mu, 1))
}
