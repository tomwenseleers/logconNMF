test_that("time-varying PSF interpolation preserves convolution and log concavity", {
  build <- getFromNamespace(".psf_build_sparse_matrix", "logconNMF")
  n <- 160L; L <- 31L
  for (g in list(convKernel("gaussian", L, list(sigma = 2)),
                 logConcSmooth(convKernel("bigaussian", L, list(sigma1 = 1, sigma2 = 3))))) {
    X <- build(seq_len(n), c(30, 130), seq_len(L) - (L + 1L) %/% 2L,
      rbind(g, g), log_floor = 0, drop_tol = 1e-12, normalize = FALSE, smooth = TRUE)
    expect_equal(as.matrix(X), as.matrix(convMatrix(g, n)), tolerance = 1e-11)
  }
  kernels <- rbind(convKernel("gaussian", L, list(sigma = 1.5)),
                   convKernel("gaussian", L, list(sigma = 4)))
  X <- build(seq_len(n), c(30, 130), seq_len(L) - (L + 1L) %/% 2L,
    kernels, log_floor = 0, drop_tol = 1e-12, normalize = FALSE, smooth = TRUE)
  expect_s4_class(X, "dgCMatrix")
  for (j in seq_len(n)) {
    h <- as.numeric(X[, j]); h <- h[h > 0]
    expect_true(all(diff(log(h), differences = 2L) < 1e-7))
  }
})

test_that("tiny log-tail roundoff cannot become a nonconcave interpolated PSF", {
  n <- 160L; L <- 51L
  g <- exp(-2 * abs(-25:25)); g[50L] <- .99 * g[50L]; g <- g / sum(g)
  kernels <- rbind(g, convKernel("gaussian", L, list(sigma = 6)))
  X <- logconNMF:::.psf_build_sparse_matrix(seq_len(n), c(30, 130), -25:25,
    kernels, log_floor = 0, drop_tol = 1e-12, normalize = FALSE, smooth = TRUE)
  for (j in seq_len(n)) {
    h <- as.numeric(X[, j]); h <- h[h > 0]
    expect_true(all(diff(log(h), differences = 2L) < 1e-7))
  }
  expect_equal(exp(logconNMF:::.psf_log_tail(c(1, .5, 1))), c(1, .5, 1))
})

test_that("window fits learn varying PSFs and refit every original channel", {
  set.seed(211)
  n <- 1200L; L <- 31L
  centers <- c(200.5, 600.5, 1000.5)
  kernels <- t(vapply(c(1.5, 2.5, 3.5), function(s)
    convKernel("gaussian", L, list(sigma = s)), numeric(L)))
  X <- logconNMF:::.psf_build_sparse_matrix(seq_len(n), centers, seq_len(L) - 16L,
    kernels, log_floor = 0, drop_tol = 1e-12, normalize = FALSE, smooth = TRUE)
  A <- matrix(0, n, 3)
  at <- seq.int(45, n - 45L, by = 40L)
  A[at, ] <- matrix(runif(length(at) * 3, 10000, 80000), length(at), 3)
  mu <- as.matrix(X %*% A) + 100
  Y <- matrix(rpois(length(mu), mu), n, 3)
  start <- convKernel("gaussian", L, list(sigma = 6))
  fit <- l0glmBlindDeco(Y, kernel_est = start,
    baseline = "intercept", nwindows = 10L, maxiter = 6L)
  expect_equal(dim(fit$g_hat), c(10L, L))
  expect_equal(rowSums(fit$g_hat), rep(1, 10), ignore_attr = TRUE, tolerance = 1e-12)
  expect_equal(dim(fit$a_hat), dim(A))
  expect_identical(fit$X, fit$X_spikes)
  expect_equal(fit$fitted_values, fit$X %*% fit$a_hat + fit$fitted_baseline,
               ignore_attr = TRUE, tolerance = 1e-10)
  expect_equal(fit$deviance, logconNMF:::L0glm_deco_deviance(Y, fit$fitted_values, poisson(identity)))
  truth <- t(vapply(fit$psf_timepoints, function(t) {
    h <- exp(logconNMF:::.psf_interp_log_kernel(t, centers, log(kernels), smooth = TRUE))
    h / sum(h)
  }, numeric(L)))
  cosine <- rowSums(fit$g_hat * truth) / sqrt(rowSums(fit$g_hat^2) * rowSums(truth^2))
  expect_true(all(cosine > .97))
  expect_true(which.max(fit$g_hat[1L, ]) %in% 15:17)
  expect_lt(sum(fit$g_hat[10L, ]^2), sum(fit$g_hat[1L, ]^2))
  shared <- l0glmBlindDeco(Y, kernel_est = start, baseline = "intercept", maxiter = 6L)
  f1 <- function(a) {selected <- Matrix::rowSums(a) > 0; 2 * sum(selected[at]) / (sum(selected) + length(at))}
  expect_gt(f1(fit$a_hat), f1(shared$a_hat))
  expect_lt(fit$deviance, shared$deviance)
  # The design is ready for the log-concave compound-fusion workflow.
  expect_error(splogconNMF(fit$X, Y, background = matrix(1, n, 1), ncores = 1L,
    control = list(broad_repeats = 0L, full_sweeps = 0L, final_polishes = 0L)), NA)
})

test_that("blind deconvolution retains its best completed IC checkpoint", {
  set.seed(12)
  g <- convKernel("gaussian", 21L, list(sigma = 2))
  a <- numeric(200); a[c(30, 80, 120, 170)] <- 10000
  d <- list(kernel = g, Y = rpois(200, as.numeric(convMatrix(g, 200) %*% a) + 500))
  fit <- l0glmBlindDeco(d$Y, kernel_est = d$kernel,
    baseline = "intercept", maxiter = 4L)
  expect_equal(fit$selection_score, min(fit$selection_trace))
  expect_equal(fit$best_iteration, which.min(fit$selection_trace) - 1L)
  check <- l0glmSparseDeco(d$Y, kernel = fit$g_hat, baseline = "intercept")
  expect_equal(fit$selection_score, GIC(check$fit, mu_floor = 1e-8))
  expect_equal(fit$a_hat, check$coef_spikes)
})

test_that("blind proposal selection retains a calibrated broad PSF", {
  set.seed(104)
  n <- 500L;g <- dnorm(-50:50, sd = 12);g <- g / sum(g)
  a <- numeric(n);a[c(70, 160, 250, 340, 430)] <- c(5, 8, 6, 3, 7) * 1e5
  y <- rpois(n, as.numeric(convMatrix(g, n) %*% a) + 5)
  fit <- l0glmBlindDeco(y, kernel_est = g, baseline = "intercept", maxiter = 2L)
  width <- function(h) diff(range(which(h >= max(h) / 2)))
  expect_lte(abs(width(fit$g_hat) - width(g)), 2)
  expect_gt(sum(g * fit$g_hat) / sqrt(sum(g^2) * sum(fit$g_hat^2)), .995)
  expect_equal(fit$selection_score, min(fit$selection_trace))
  expect_equal(fit$fitted_values, fit$X %*% fit$a_hat + fit$fitted_baseline,
    ignore_attr = TRUE, tolerance = 1e-10)
})

test_that("local starts and window counts are validated", {
  Y <- matrix(0, 150, 2)
  g <- convKernel("gaussian", 21L)
  expect_error(l0glmBlindDeco(Y, kernel_est = g, nwindows = 0L), "nwindows")
  expect_error(l0glmBlindDeco(Y, kernel_est = g, nwindows = 20L), "at least L")
  expect_error(l0glmBlindDeco(Y, kernel_est = rbind(g, g), nwindows = 3L), "one row per window")
  fit <- suppressWarnings(l0glmBlindDeco(Y, kernel_est = rbind(g, g, g),
    L = 5L, nwindows = 3L, maxiter = 1L, kernel_smoothfun = NULL))
  expect_equal(fit$g_hat, matrix(rep(g, each = 3L), 3), ignore_attr = TRUE)
  expect_true(all(fit$a_hat == 0))
  expect_equal(dim(fit$X), c(150L, 150L))
})

test_that("time-varying Gaussian fits retain their individual channels", {
  set.seed(14)
  g <- convKernel("gaussian", 21L, list(sigma = 2))
  A <- matrix(0, 240, 2); A[c(35, 95, 155, 210), ] <- 20000
  mu <- as.matrix(convMatrix(g, 240) %*% A) + 200
  Y <- mu + matrix(rnorm(length(mu), sd = 5), 240, 2)
  fit <- l0glmBlindDeco(Y, family = gaussian(identity), kernel_est = g,
    baseline = "intercept", nwindows = 2L, maxiter = 2L, parallelize = FALSE)
  expect_equal(dim(fit$a_hat), c(240L, 2L))
  expect_true(all(is.finite(fit$g_hat)))
  expect_true(is.finite(fit$deviance))
  expect_equal(fit$fitted_values, fit$X %*% fit$a_hat + fit$fitted_baseline,
               ignore_attr = TRUE, tolerance = 1e-9)
})
